function displayTimeStamp (e){
    var time = new Date();
    alert("submitted at:" + time.getMilliseconds());
}